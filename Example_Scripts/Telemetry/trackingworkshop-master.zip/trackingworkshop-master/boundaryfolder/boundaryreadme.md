# Boundary read me

This folder contains a simple example shapefile for a line boundary. This shapefile is used to limit kernel home ranges.
